# ZqFOC PyQt6 串口上位机

适配仓库：<https://github.com/jzq20000919/ZqFOC>（STM32G431，USART2，`User/foc_vofa.c`）。

## 1. 安装与运行（Windows / VS Code）

在本文件夹中打开 VS Code 终端：

```powershell
python -m pip install -r requirements.txt
python zqfoc_pc.py
```

如果已使用 `.venv`，先在 VS Code 右下角/命令面板中选择正确的解释器，再运行上述命令。若全新项目需要创建环境：

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python zqfoc_pc.py
```

无需安装 Qt Creator 或 Qt Designer。

## 2. 串口与接线

- 固件：USART2，PB3=TX，PB4=RX；2,000,000 bps、8 数据位、无校验、1 停止位。
- 若使用外部 USB-TTL：MCU TX → USB-TTL RX，MCU RX ← USB-TTL TX，GND 共地；**必须使用兼容 3.3V TTL 逻辑电平的设备，不能把 RS-232 电压直接连到 MCU**。板载调试器 VCP 是否已接到 PB3/PB4 应以你的实物原理图为准。
- 连接之前，关闭占用同一个 COM 端口的 VOFA+、其他串口助手。
- 2 Mbps 已足以传输现有 44 字节、最多 1000 帧/秒的数据；不要为了追求最高名义波特率牺牲可靠性。串口桥接芯片/驱动也必须支持 2 Mbps。

## 3. 功能与操作

1. 选择 COM 端口，点击“连接”。当前固件仅在 `FOC_STATE_RUNNING` 的 ADC 电流环回调中请求遥测；停机和对齐期间可能没有波形，这是正常情况。
2. 点击“切换速度模式 (MS)”或者“切换位置模式 (MP)”。**注意：MS 清空速度目标；MP 切换到当前位置保持。**
3. 点击“启动 START”。MCU 会执行原本的电角度对齐及释放流程（约 1.8 秒以上）。**等待约 2 秒且确认电机正常运行后**再按“设置速度”或“设置位置”。在启动前/对齐中发送目标可能被 MCU 启动流程覆盖。
4. 设置速度范围 -2600~2600 rpm；设置位置范围 0~359.99°，为单圈绝对机械角，最短路径定位，**不是相对转动角度**。发送位置使用 `Axx`，固件会自动切换位置模式。
5. 结束时点击“停止 STOP”并确认实机已停机，然后再断开串口。主动断开和关闭窗口会**尝试**发送 `STOP`，但不保证 MCU 收到。

四个图表：速度 Ref/Actual、单圈位置 Ref/Actual、Iq Ref/Actual、Id Ref/Actual。上部数字卡片格式为“**实际值 / 目标值**”。右上串口信息会显示接收帧率。图表显示最近 8 秒，X 轴采用 PC 收包时间（无 MCU 时间戳）；显示点约每 10 ms 取一次接收的最新帧，绘图约 20 fps，不影响 STM32 原本的 16 kHz 电流环。

## 4. 现有协议，无需修改 STM32 工程

### MCU → 上位机：JustFloat

每帧 44 字节：10 个小端 `float32` + 帧尾 `00 00 80 7F`。

| CH | 字段 | 单位 |
|---|---|---|
| 0 | speed_ref | rpm |
| 1 | speed_fbk | rpm |
| 2 | id_ref | A |
| 3 | id | A |
| 4 | iq_ref | A |
| 5 | iq | A |
| 6 | vd | V |
| 7 | vq | V |
| 8 | position_ref | ° |
| 9 | position_actual | ° |

### 上位机 → MCU：ASCII + LF (`\n`)

- `MS\n` 速度模式；`MP\n` 位置模式
- `START\n` 启动；`STOP\n` 停机（不是仅设零速）
- `S300\n`, `S-300\n` 设置速度 rpm
- `A90\n` 设置单圈角度 90°，同时选择位置模式

代码只操作串口并显示数据，不会更改 FOC PI、PWM 或中断时序。

## 5. 已知限制 / 安全

- **固件没有通过 UART 返回命令 ACK 和 `FOC_STATE_RUNNING`，所以 GUI 不能判断 START/STOP 是否真正执行，也不能保证 2 秒后对齐成功。** PC 侧绝不显示“电机已运行”这样的虚假状态。
- 现有遥测没有 CRC 和 MCU 时间戳；图表是在线监控，不是具有确定时间基准的高速示波器。接收程序使用 4 字节 JustFloat 帧尾并检查浮点数据合理性进行重同步。
- USB 意外拔出、Python 崩溃、PC 断电时，程序不能保证向 MCU 发出 STOP。真实设备请配备独立电源隔离/急停与固件级安全机制。
- 当前工程串口、CAN、按键可能同时控制电机；最好只让**一个**上位控制源下发模式及目标，避免互相覆盖。
- 没有实机联机验证；需要在你自己的 STM32 板上测试，初次使用建议低电压、无负载、低目标速度。
